
% Theodorsen model built for implementation of P-K method
% by G. QUARANTA
%
%
function [Ma, CaNC, CaC, KaC, Ck] = Theodorsen_pk(a, k)

Ma = [ 1,         -a;
      -a,   (1/8 + a^2)];
  
CaNC = [ 0,         -1;
         0,  (1/2 - a)];


CaC = [        2,          (1 - 2*a);
        -(1+2*a),    -(1/2 - 2*a^2)];

KaC = [ 0,            1;
        0,  -(1/2 + a)];
    
    
Ck = besselh(1,2,k) ./ (besselh(1,2,k) + 1i * besselh(0,2,k));
