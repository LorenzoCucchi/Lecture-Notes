
% FLUTTER STATE-SPACE MEYHOD
% by G Quaranta


clear all
close all
clc

Toll = 1e-6;
maxIter = 100;


mu = 10;
xt = 0.05;
rt = 0.5;

b = 1;
e = 0.5;
R = 0.5;
cla   = 2*pi;

xih = 0.0;
xit = 0.0;

a = e - 0.5;

% structural dofs
ns = 2;
% aerodynamic states
na = 2;


Ms = [ 1,    xt;  
      xt, rt^2];

Ks = [R^2      0;
      0    rt^2];
Cs = [2*xih*R,           0;
            0, 2*xit*rt^2];
 
V = [     eye(ns), zeros(ns,ns), zeros(ns,na);
     zeros(ns,ns),          Ms,  zeros(ns,ns);
     zeros(na,ns), zeros(na,ns),     eye(na)]; 

A = [zeros(ns,ns),      eye(ns),  zeros(ns,na); 
              -Ks,          -Cs,  zeros(ns,na);
     zeros(na,ns), zeros(na,ns), zeros(na,na)]; 

U = 0.0:0.02:1.8;

ev = zeros(2*ns+na,2*ns+na, length(U));
s = zeros(2*ns+na, length(U));
% sensitivities of the eigenvalue and eigenvector
d = zeros(2*ns+na+1,2*ns+na,length(U));
[ev(:,:,1), sx] = eig(A,V);
s(:,1) = diag(sx);
% could be called once because it does not depend on U
[Ma, CaNC, Ka, Ca, C0, Bk, Bc, Aa] = Theodorsen_ss(a);
Ap = [      zeros(ns,ns),   zeros(ns),  zeros(ns,na); 
       4*U(2)^2/mu*Ka, -1/mu*CaNC + 2/mu*Ca,  2/mu*C0;
          2*U(2)*Bk,                     Bc,      Aa]; 
%compute initial sensitivities
for j = 1 : 2*ns+na 
    Z = [s(j,1) * V - A,    V * ev(:,j,1);
         2 * ev(:,j,1)',               0];
    B = [Ap * ev(:,j,1); 0];
    d(:,j,1) = Z\B;
end



for i = 2 : length(U) 
    deltaP = U(i) - U(i-1);
    V = [     eye(ns), zeros(ns,ns), zeros(ns,na);
        zeros(ns,ns),   Ms+1/mu*Ma,  zeros(ns,ns);
        zeros(na,ns), zeros(na,ns),     eye(na)];
    
    A = [      zeros(ns,ns),      eye(ns),  zeros(ns,na);
        -Ks+2*U(i)^2/mu*Ka, -Cs-U(i-1)/mu*CaNC+2*U(i)/mu*Ca,  2*U(i)/mu*C0;
        U(i)^2*Bk,                            U(i)*Bc,      U(i)*Aa];
    for j = 1 : 1 : 2*ns
        % estimate the new values for s and s_v
        s_e = s(j,i-1) + d(end,j,i-1)*deltaP;
        ev_e = ev(:,j,i-1) + d(1:end-1,j,i-1)*deltaP;
        ev_e = ev_e ./ norm(ev_e);
    
        
        nr0 = norm([s_e; ev_e]);
        
        Res = [-(s_e * V  - A) * ev_e;
                1 - ev_e' * ev_e    ];
        
        nrm = norm(Res)/nr0;
        count = 0;
        while (nrm > Toll) && (count < maxIter)
            Z = [(s_e * V  - A), V  * ev_e;
                      2 * ev_e',        0];
            Fm = Z\Res;
            s_e = s_e + Fm(end);
            ev_e = ev_e + Fm(1:end-1);
            Res = [-(s_e * V  - A) * ev_e;
                1 - ev_e' * ev_e    ];
            nrm = norm(Res)/nr0;
            count = count + 1;
        end
        if (count == maxIter)
            disp(['Warning maximum iteration reached i=', num2str(i), ', j=', num2str(j)]);
        end
        s(j,i) = s_e;
        if (real(s(j,i)) > 0) 
            disp(['Positive damping at Step: ', num2str(i), ' Speed: ', num2str(U(i))]);
        end
        ev(:,j,i) = ev_e;
        
        % new sensitivities
        Ap = [        zeros(ns,ns),            zeros(ns),  zeros(ns,na); 
                  4*U(i)^2/mu*Ka, -1/mu*CaNC + 2/mu*Ca,       2/mu*C0;
                       2*U(i)*Bk,                   Bc,           Aa]; 
       
        Z = [s(j,i) * V - A,    V * ev(:,j,i);
             2 * ev(:,j,i)',               0];
        B = [Ap * ev(:,j,i); 0];
        d(:,j,i) = Z\B;
    end
end

c = ['brgkmcybrgkmcybrgkmcy'];
plot(real(s(1,:)), imag(s(1,:)), [c(1),'*'])
xlabel('Real');
ylabel('Imag');
title('Eigenvalue Plot');
for i = 1:1:2*ns
    hold on; plot(real(s(i,:)), imag(s(i,:)), [c(i),'*'])
end
grid on;


figure(3);
title('Eigenvalue Plot');
ax1 = subplot(2,1,1);
plot(U, abs(imag(s(1,:))/2/pi), [c(1),'*-'])
for i = 1:1:2*ns
    hold on; plot(U, abs(imag(s(i,:))/2/pi), [c(i),'*-'])
end
grid on; xlabel(ax1,'U');
ylabel(ax1,'Freq, Hz');

ax2 = subplot(2,1,2);
plot(U, 2*real(s(1,:))./(abs(imag(s(1,:)))+1*(abs(imag(s(1,:)))< 0.001)), [c(1),'*-'])
for i = 1:1:2*ns
    hold on; plot(U, 2*real(s(i,:))./(abs(imag(s(i,:)))+1*(abs(imag(s(i,:)))< 0.001)), [c(i),'*-'])
end
xlabel(ax2,'U');
ylabel(ax2,'g');
% to focus on low g to find flutter
grid on;
ylim([-1,1]);   