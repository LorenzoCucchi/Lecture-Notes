
% FLUTTER P-K MEYHOD
% by G Quaranta


clear all
close all
clc

Toll = 1e-6;
maxIter = 100;


mu = 10;
xt = 0.05;
rt = 0.5;

b = 1;
e = 0.5;
R = 0.5;
cla   = 2*pi;

xih = 0.0;
xit = 0.0;

a = e - 0.5;


ns = 2;


Ms = [ 1,    xt;  
      xt, rt^2];

Ks = [R^2      0;
      0    rt^2];
Cs = [2*xih*R,           0;
            0, 2*xit*rt^2];
 
V = [     eye(ns), zeros(ns,ns);
     zeros(ns,ns),          Ms]; 

A = [zeros(ns,ns), eye(ns); 
              -Ks,    -Cs]; 

U = 0.01:0.01:1.8;

ev = zeros(2*ns,2*ns, length(U)+1);
s = zeros(2*ns, length(U)+1);
[ev(:,:,1), sx] = eig(A,V);
s(:,1) = diag(sx);

for i = 2 : length(U) + 1
    for j = 1 : 2 : 2*ns
        k = imag(s(j,i-1));
        if k < 0.001
            k = 0.001;
        end
%        k = 0;
        nIt = 0;
        while (abs(s(j,i-1) - s(j,i)) > Toll) && nIt < maxIter
            [Ma, CaNC, CaC, KaC, Ck] = Theodorsen_pk(a, k);
    
            V = [     eye(ns),                              zeros(ns,ns);
                 zeros(ns,ns),  Ms+1/mu*Ma + U(i-1)/mu*CaC*imag(Ck)/k]; 

            A = [                     zeros(ns,ns), eye(ns); 
                  -(Ks+2*U(i-1)^2/mu*KaC*real(Ck)),    -(Cs+U(i-1)/mu*(CaNC+CaC*real(Ck)+2*U(i-1)*KaC*imag(Ck)/k))]; 
             
%              V = [     eye(ns),   zeros(ns,ns);
%                 zeros(ns,ns),      Ms+1/mu*Ma]; 

%            A = [                     zeros(ns,ns), eye(ns); 
%                  -(Ks+2*U(i-1)^2/mu*KaC),    -(Cs+U(i-1)/mu*(CaNC+CaC))]; 

            [ev(:,j,i), sx] = eigs(A,V,1,s(j,i-1));
            s(j,i) = diag(sx);
            k = imag(s(j,i));
            if k < 0.001
                k = 0.001;
            end
%            k = 0;
            nIt = nIt + 1;
        end
    end
end

c = ['brgkmcybrgkmcybrgkmcy'];
plot(real(s(1,:)), imag(s(1,:)), [c(1),'*'])
xlabel('Real');
ylabel('Imag');
title('Eigenvalue Plot');
for i = 1:2:2*ns
    hold on; plot(real(s(i,:)), imag(s(i,:)), [c(i),'*'])
end
grid on;

U = [0, U];
figure(3);
title('Eigenvalue Plot');
ax1 = subplot(2,1,1);
plot(U, abs(imag(s(1,:))/2/pi), [c(1),'*-'])
for i = 1:2:2*ns
    hold on; plot(U, abs(imag(s(i,:))/2/pi), [c(i),'*-'])
end
grid on; xlabel(ax1,'U');
ylabel(ax1,'Freq, Hz');

ax2 = subplot(2,1,2);
plot(U, 2*real(s(1,:))./(abs(imag(s(1,:)))+1*(abs(imag(s(1,:)))< 0.001)), [c(1),'*-'])
for i = 1:2:2*ns
    hold on; plot(U, 2*real(s(i,:))./(abs(imag(s(i,:)))+1*(abs(imag(s(i,:)))< 0.001)), [c(i),'*-'])
end
xlabel(ax2,'U');
ylabel(ax2,'g');
% to focus on low g to find flutter
grid on;
ylim([-1,1]);