
% Theodorsen model built for implementation of State space method
% by G. QUARANTA
%
%
function [Ma, CaNC, Ka, Ca, C0, Bk, Bc, A] = Theodorsen_ss(a)

Ma   = [ 1,         -a;
        -a,   (1/8 + a^2)];
CaNC = [ 0,         -1;
         0,   (1/2 - a)];

Cw  = [-1; (1/2 + a)];
Bw1 = [0, 1];
Bw2 = [1, (1/2 - a)];

% AT = [-0.3455,  -0.01365;
%             1,         0];
% BT = [1;  0];
% CT = [0.1081, 0.006825];
% DT = 0.5;

AT = [   0,  -0.01312;
         1,    -0.361];
BT = [1;  0];
CT = [0.114, -0.03458];
DT = 0.5;
  
Ka = Cw*DT*Bw1;
Ca = Cw*DT*Bw2;
C0 = Cw*CT;
Bk = BT*Bw1;
Bc = BT*Bw2;
A = AT;